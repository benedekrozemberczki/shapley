
class PermutationSampling(object):


    def __init__(self, a, b):
        self.a = a
        self.b = b


    def solve_game(self):
        return self.a+self.b
